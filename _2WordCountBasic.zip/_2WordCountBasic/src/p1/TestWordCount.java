package p1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class TestWordCount {
public static void main(String[] args) throws FileNotFoundException {
	
	Scanner scan=new Scanner(new File("input_data/word.txt"));
	HashMap<String,Integer> map=new HashMap<String,Integer>();
	while(scan.hasNext())
	{
		String line=scan.nextLine();
		String  words[]=line.split(" ");
		
		for(String word:words)
		{
			int count=0;
			System.out.println(word);
			if(map.containsKey(word)){
				count=(Integer)map.get(word);
			}
			count++;
			map.put(word, count);
		}
		
		System.out.println(map);
	}
}
}
