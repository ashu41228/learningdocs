import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.BZip2Codec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;

public class MaxTemperatureDriver {
	private static final Logger LOGGER = Logger.getLogger(MaxTemperatureDriver.class);

	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {

		Path inputDir = new Path(INPUT_DIR);
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "MaxTemp");
		
		//Looks like they are deprecated
		/*conf.set("mapred.output.compress", "true");
		conf.set("mapred.output.compression.codec","org.apache.hadoop.io.compress.GzipCodec");//No effect
		conf.set("mapred.output.compression.codec",
				"org.apache.hadoop.io.compress.SnappyCodec");*/
		 
		
		FileOutputFormat.setCompressOutput(job, true);
		//FileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);
		//FileOutputFormat.setOutputCompressorClass(job, SnappyCodec.class);//Looks like not supporting
		//FileOutputFormat.setOutputCompressorClass(job, DefaultCodec.class);
		 FileOutputFormat.setOutputCompressorClass(job, BZip2Codec.class);

		job.setNumReduceTasks(4);// No effect on local mode.
		job.setJarByClass(MaxTemperatureDriver.class);
		job.setJobName("Max temperature");
		job.setMapperClass(MaxTemperatureMapper.class);
		job.setPartitionerClass(MaxTemperaturePartitioner.class);
		job.setReducerClass(MaxTemperatureReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);

		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir, true);
		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution

		if (flag) {
			//file is compressed.Please verify manually
			//MyIOUtils.readOutputFile(OUTPUT_DIR);
		}
	}
}
