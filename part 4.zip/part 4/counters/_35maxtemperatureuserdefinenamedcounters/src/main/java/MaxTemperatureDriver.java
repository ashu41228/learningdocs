import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MaxTemperatureDriver {
	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {

		Path inputDir = new Path(INPUT_DIR);
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.
		
		Job job = Job.getInstance();
		//delete the output files at every run
		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir,true);   
	   
		job.setJarByClass(MaxTemperatureDriver.class);
		job.setJobName("Max temperature");
		FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);
		job.setMapperClass(MaxTemperatureMapper.class);
		job.setReducerClass(MaxTemperatureReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution

		if (flag) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}
	}
}
