import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MaxTemperatureMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	// 1901 32
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		context.getCounter("MYTEMPERATURE", "TOTAL_PROCESSED_RECORDS").increment(1);

		System.out.println("MaxTemperatureMapper.map(-,-,-)");
		String data[] = value.toString().split(" ");

		context.getCounter("Year Wise Counter", data[0]).increment(1);

		int temp = Integer.parseInt(data[1]);
		if (temp > 30)
			context.getCounter("MYTEMPERATURE", "TEMP_GREATER_30").increment(1);
		;
		context.write(new Text(data[0]), new IntWritable(temp));
	}
}

/*
 * MYTEMPERATURE= Temperature Details!!! TOTAL_PROCESSED_RECORDS= total
 * Processed Records TEMP_GREATER_30= Temperature Greater than 30
 */