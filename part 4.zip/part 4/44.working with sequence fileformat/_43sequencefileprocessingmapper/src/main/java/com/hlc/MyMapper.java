package com.hlc;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<Text, NullWritable, Text, NullWritable> {

	@Override
	public void map(Text key, NullWritable value, Context context)throws IOException, InterruptedException {
		System.out.println("MaxTemperatureMapper.map(-,-,-)");
		System.out.println("Value="+key);
		context.write(key, NullWritable.get());
		
		//TODO find out the max temperature for each year
		//Write the reducer code as well.
	}
}
