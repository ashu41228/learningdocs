package com.hlc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;

public class MyDriver {

	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {

		Path inputDir = new Path(INPUT_DIR);
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.
		Configuration conf = new Configuration();

		Job job = Job.getInstance(conf, "Text to Sequence File Creator");
		job.setNumReduceTasks(0);// We dont need reducer
		job.setJarByClass(MyDriver.class);

		job.setMapperClass(MyMapper.class);
		job.setInputFormatClass(SequenceFileInputFormat.class);
		// job.setOutputFormatClass(SequenceFileOutputFormat.class);

		FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);

		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir, true);

		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution

		if (flag) {
			//MyIOUtils.readOutputFile(OUTPUT_DIR);
		}

	}
}
