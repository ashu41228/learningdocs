import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.SequenceFile.Writer;
import org.apache.hadoop.io.Text;

public class _1SequenceFileCreator {
/*In this program
 * 1.Read the data from HDFS and store it in local file system (line 22 -44)
 * 2.Read the local data that was created in step1 line by line
 * 3.For each above line,
 *        get key value pair & append it in SequenceFile.Writer object
 * 4.flush  the writer object & store the sequence file in HDFS
 * 5.Close all scanner and writer connection
*/	
	private static final File OUTPUT_LOCAL_FILE_PATH = new File("/home/hduser/temp1.txt");
	private static final String INPUT_HDFS_PATH = "hdfs://localhost:9000/temp_data/temp1.txt";

	private static Configuration conf = new Configuration();
	private static FileSystem hdfs;

	public static void main(String[] args) throws Exception {
		// Create Filesystem object pointing to hdfs input_file
		hdfs = FileSystem.get(URI.create(INPUT_HDFS_PATH), conf);
		downloadFromHDFSToLocal();
		// If you are here,Your data is written successfully into local file.
		createSequenceFile();
	}

	private static void createSequenceFile() throws IOException {
		Scanner scan = new Scanner(OUTPUT_LOCAL_FILE_PATH);
		String outputPath = "hdfs://localhost:9000/sequence_temp_data/temp1.txt";
		Text key = new Text();
		Text value = new Text();
		
		SequenceFile.Writer writer = SequenceFile.createWriter(conf, Writer.file(new Path(outputPath)),
				Writer.keyClass(key.getClass()), Writer.valueClass(value.getClass()));

		while (scan.hasNextLine()) {
			String line = scan.nextLine();
			System.out.println("current Line:" + line);
			key.set(line);
			writer.append(key, value);// value is emptyText
			// writer.append(new Text(line),new Text());
		}
		scan.close();
		// writer.close();
		IOUtils.closeStream(writer);// pushes the data into the destination ie
									// HDFS.
	}

	private static void downloadFromHDFSToLocal() throws IOException {

		// inputstream object to read data from hdfs path
		InputStream in = hdfs.open(new Path(INPUT_HDFS_PATH)); // return
		// FSDataInputStream
		// containing
		// DFSDataInputStreaming
		// OutputStream object to write the data in local file system
		OutputStream os = new FileOutputStream(OUTPUT_LOCAL_FILE_PATH);

		// start reading data from inputstream and write them to outputstream
		// read 2kb of data at one time,
		// dont close the stream automatically,let programmer close the stream
		IOUtils.copyBytes(in, os, 4096, false);
		IOUtils.closeStream(in);// manually closing the stream
	}
}
