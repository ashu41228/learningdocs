import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.util.ReflectionUtils;


public class _2SequenceFileReader {

	public static void main(String[] args) throws Exception {

		final String url = "hdfs://localhost:9000/sequence_temp_data/temp1.txt";
		
		Configuration conf = new Configuration();
		// accepts url and configuration and creates a FileSystem Out of it
		FileSystem fs = FileSystem.get(URI.create(url), conf);

		Path inputPath = new Path(url);
		
		SequenceFile.Reader reader = new SequenceFile.Reader(fs, inputPath,conf);
		
		Writable key = (Writable) ReflectionUtils.newInstance(reader.getKeyClass(), conf);
		Writable value = (Writable) ReflectionUtils.newInstance(reader.getValueClass(), conf);

		
		
		while (reader.next(key, value)) {
			System.out.println("Current Position" + reader.getPosition());
			
			System.out.println("key :"+key);//value is empty 
			//String syncSeen=reader.syncSeen()? "*":"";
			//System.out.println(syncSeen);
			//System.out.println(pos+" : "+syncSeen+" : "+key+" : "+value);
			//pos=reader.getPosition();//begining of the next record
		}
		
		IOUtils.closeStream(reader);
	}
}
