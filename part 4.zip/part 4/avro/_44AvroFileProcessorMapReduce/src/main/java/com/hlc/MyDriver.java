package com.hlc;
import org.apache.avro.Schema;
import org.apache.avro.mapreduce.AvroJob;
import org.apache.avro.mapreduce.AvroKeyInputFormat;
import org.apache.avro.mapreduce.AvroKeyValueOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import p1.Student;

public class MyDriver{
	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {
		
		Path inputDir = new Path(INPUT_DIR);
		Path outputDir = new Path(OUTPUT_DIR);
		
		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.
		
	    
	    Configuration conf = new Configuration();
	    
		Job job = Job.getInstance(conf, "Avro Processor"); //Configuration is not necessary
	    job.setNumReduceTasks(1);//We dont need reducer
		job.setJarByClass(MyDriver.class);
	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);
	   
	    FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);
		
		job.setInputFormatClass(AvroKeyInputFormat.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		
		//my avro files schema is based on Student class
		AvroJob.setInputKeySchema(job, Student.getClassSchema());
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		AvroJob.setOutputKeySchema(job, Schema.create(Schema.Type.INT));
		AvroJob.setOutputValueSchema(job, Schema.create(Schema.Type.FLOAT));

		
		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir,true);
			
		System.exit(job.waitForCompletion(true) ? 0 : 1);

		}
}