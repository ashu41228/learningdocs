package com.hlc;
import java.io.IOException;

import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import p1.Student;

public class MyMapper extends Mapper<AvroKey<Student>, NullWritable, IntWritable, Text> {

	@Override
	public void map(AvroKey<Student> key, NullWritable value, Context context)throws IOException, InterruptedException {
		System.out.println("MaxTemperatureMapper.map(-,-,-)");
		Student st=key.datum();
		
		IntWritable studId = new IntWritable(st.getStudentId());
		Text subName=new Text(st.getSubjectName().toString());
		FloatWritable studMarks=new FloatWritable(st.getStudentMarks());
		
		System.out.println("Value="+key);
		context.write(studId, new Text(subName+" "+studMarks));
	}
} // end of mapper class
