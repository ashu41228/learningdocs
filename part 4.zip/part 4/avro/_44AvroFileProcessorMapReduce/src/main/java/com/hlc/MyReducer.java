package com.hlc;
import java.io.IOException;

import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapred.AvroValue;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<IntWritable,Text,AvroKey<Integer>,AvroValue<Float>> {
		
		protected void reduce(IntWritable key, Iterable<Text> values, Context context) 
				throws IOException, InterruptedException {
			
			Float total=0f;
			for(Text value:values)
			{//physics 19
				total+=Float.parseFloat(value.toString().split(" ")[1]);
			}
			context.write(new AvroKey<Integer>(key.get()), new AvroValue<Float>(total));
		}
	} // end of reducer class 

