package com.hlc;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, Text, Text, Text> {

	
	public void reduce(Text key, Iterable<Text> empDetails, Context context)
			throws IOException, InterruptedException {
		//empId+" "+empName+" "+empSalary+" "+empEmail
		Integer max_salary=Integer.MIN_VALUE;
		Text highPaidEmployee=new Text();
		
		for(Text empDetail:empDetails)
		{
			int salary=Integer.parseInt(empDetail.toString().split(" ")[2]);
			if(salary>max_salary){
				max_salary=salary;
				highPaidEmployee.set(empDetail);
			}
		}
		context.write(highPaidEmployee, new Text());
		
	}

}