package com.hlc;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

public class MyXMLInputFormat extends TextInputFormat {
	public MyXMLInputFormat() {
		System.out.println("MyXMLInputFormat()");
	}

	public RecordReader<LongWritable, Text> createRecordReader(
			InputSplit split, TaskAttemptContext context) {
		System.out.println("MyXMLInputFormat.createRecordReader(-,-)");
		return new MyXMLRecordReader();
	}
}