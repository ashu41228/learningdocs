package com.hlc;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DataOutputBuffer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

/**
 * XMLRecordReader class to read through a given xml document to output xml
 * blocks as records as specified by the start tag and end tag
 *
 */

public class MyXMLRecordReader extends RecordReader<LongWritable, Text> {

	public static final String START_TAG_KEY = "xmlinput.start";
	public static final String END_TAG_KEY = "xmlinput.end";
	public static final String UTF8 = "utf-8";

	private byte[] startTag;
	private byte[] endTag;
	private long start;
	private long end;
	private FSDataInputStream fsin;
	private DataOutputBuffer buffer = new DataOutputBuffer();

	private LongWritable key = new LongWritable();
	private Text value = new Text();

	@Override
	public void initialize(InputSplit split, TaskAttemptContext context)
			throws IOException, InterruptedException {

		System.out.println("MyXMLRecordReader.initialize(-,-)");
		// get access to configuration object
		Configuration conf = context.getConfiguration();
		// get access to those start tag and close tag
		startTag = conf.get(START_TAG_KEY).getBytes(UTF8);//<employee>
		endTag = conf.get(END_TAG_KEY).getBytes(UTF8);//</employee>

		FileSplit fileSplit = (FileSplit) split;

		// open the file and seek to the start of the split
		// get start and end positions
		start = fileSplit.getStart();
		end = start + fileSplit.getLength();
		System.out.println("Start Pos:" + start + " End Pos:" + end);

		// get Access to the file.
		Path file = fileSplit.getPath();
		System.out.println("File Path :" + file);
		// get Access to HDFS fileSystem
		FileSystem fs = file.getFileSystem(conf);
		fsin = fs.open(file);// get Access to the file in HDFS
		fsin.seek(start);// go to the start position of the file
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		System.out.println("MyXMLRecordReader.nextKeyValue()");
		if (fsin.getPos() < end) { // If file read is not complete

			// buffer=<employee>.......</employee>
			if (readUntilMatch(startTag, false)) // read until the matching
													// start tags encounters
			{
				try {
					buffer.write(startTag);// write the starting tag into the
											// buffer

					if (readUntilMatch(endTag, true)) {// go till the matching
														// end tag and write the
														// data into the buffer
						key.set(fsin.getPos()); // set the key as the offset
												// value
						value.set(buffer.getData(), 0, buffer.getLength());// write
																			// all
																			// the
																			// buffer,data
																			// into
																			// value
						return true;
						
					}
				} finally {
					buffer.reset();
				}
			}
		}
		return false;
	}

	@Override
	public float getProgress() throws IOException {
		//return (fsin.getPos() - start) / (float) (end - start);
		return fsin.getPos()/(float)end;
	}

	@Override
	public LongWritable getCurrentKey() throws IOException,
			InterruptedException {
		return key;
	}

	@Override
	public Text getCurrentValue() throws IOException, InterruptedException {
		return value;
	}

	@Override
	public void close() throws IOException {
		fsin.close();
	}

	// <employee>,false
	private boolean readUntilMatch(byte[] startTag, boolean withinBlock)
			throws IOException {
		// startTag= </employee>   withInBlock=true
		int i = 0;

		/*
		 * <employees> <employee> <empid>101</empid>...</employee>
		 */
		// fsin-><employees>...</employees>
		while (true) {
			int b = fsin.read();// Reads the next byte of data from this input
								// stream
			// end of file:
			if (b == -1) {
				return false;
			}
			// save to buffer:
			if (withinBlock) {
				buffer.write(b);
			}
			// match=<employees>
			// check if we're matching: b==<employee>
			if (b == startTag[i]) { // </employee>
				i++;
				if (i >= startTag.length)// are all characters matched
				{
					return true;
				}
			} else {
				i = 0;// if any character didnot match,reset i to 0
			}
			// see if we are trying to read the <employee> tag but we have cross the end point.
			if (!withinBlock && i == 0 && fsin.getPos() >= end)
				return false;
		}
	}
}
