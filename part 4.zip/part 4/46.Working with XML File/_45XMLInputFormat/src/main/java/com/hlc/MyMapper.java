package com.hlc;
import java.io.IOException;
import java.io.StringBufferInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.w3c.dom.Document;

public class MyMapper extends Mapper<LongWritable, Text, Text, Text> {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		new MyMapper().map(null, null, null);
	}
	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String document = value.toString();
		/*String document="<employee>"+
		"<empid>105</empid>    <empName>kaith</empName>    <empSalary>9000</empSalary><empCompany>nowonders</empCompany>"+
		"<empMail>kaith@nowonders.com</empMail></employee>";*/
		
		System.out.println("Line:" + document);
		
		//Get Access to DocumentBuilderFactory object
		DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
		
		try {
			//Get access to builder object
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc=builder.parse(new StringBufferInputStream(document));
			doc.getDocumentElement().normalize();
			
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String empId = doc.getElementsByTagName("empId").item(0).getTextContent();
			String empName=doc.getElementsByTagName("empName").item(0).getTextContent();
			String empSalary=doc.getElementsByTagName("empSalary").item(0).getTextContent();
			String empEmail=doc.getElementsByTagName("empEmail").item(0).getTextContent();
		   
		    System.out.println(empId);
		    System.out.println(empName);
		    System.out.println(empSalary);
		    System.out.println(empEmail);
		    
		    context.write(new Text("1"),new Text(empId+" "+empName+" "+empSalary+" "+empEmail));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}