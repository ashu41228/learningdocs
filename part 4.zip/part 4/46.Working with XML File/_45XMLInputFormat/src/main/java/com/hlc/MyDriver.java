package com.hlc;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

//Find EmployeeName,companyName with highest  average percentage in Btech and 12th 
public class MyDriver {
	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {

		Path inputDir = new Path(INPUT_DIR);
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.

		Configuration conf = new Configuration();

		conf.set("xmlinput.start", "<employee>");
		conf.set("xmlinput.end", "</employee>");
		Job job = Job.getInstance(conf);
		job.setJarByClass(MyDriver.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);

		job.setInputFormatClass(MyXMLInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		// job.setOutputValueClass(NullWritable.class);

		FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);
		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir, true);

		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution

		if (flag) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}
	}
}
