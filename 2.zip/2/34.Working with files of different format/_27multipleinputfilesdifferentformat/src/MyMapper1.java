import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper1 extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	/*Will Process
	101,f,3000
	102,m,4000
	103,f,5000
	104,m,5000
	105,m,9000*/
	
	public void map(LongWritable offset, Text value, Context context) throws IOException,
			InterruptedException {
		System.out.println("MyMapper1.map(-,-,-)");
		String line = value.toString();
		String[] words = line.split(",");
		String gender = words[1];
		int salary= Integer.parseInt(words[2]);
		System.out.println(gender+"::"+salary);
		context.write(new Text(gender), new IntWritable(salary));
	}
}