import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

//Find EmployeeName,companyName with highest  average percentage in Btech and 12th 
public class MyDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Path input_dir1=new Path("hdfs://localhost:54310/emp_data/empList1.txt"); //
		Path input_dir2=new Path("hdfs://localhost:54310/emp_data/empList2.txt");
		
	    Path output_dir=new Path("hdfs://localhost:54310/output_data/");
		
		/*Reads hadoop configuration file,and points to the hadoop cluster*/
		Configuration conf = new Configuration();
		
		//Create an object of Job by specifying conf object
		Job job = new Job(conf, "MyWordCountJob");
		 
		//Set your main class in the jar file that will be created in future
	    job.setJarByClass(MyDriver.class);
	   
	    job.setMapperClass(MyMapper1.class);  //WE NEED TO CREATE SEPARATE MAPPER FOR EACH FILE//
	    job.setMapperClass(MyMapper2.class);  //WE NEED TO CREATE SEPARATE MAPPER FOR EACH FILE// 
	    
	    job.setReducerClass(MyReducer.class);
	    
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);

	    //Setting your input and output directory
	    //empList1.txt will be processed by MyMapper1
	    MultipleInputs.addInputPath(job, input_dir1, TextInputFormat.class, MyMapper1.class); //WE NEED TO SET SEPARATE MAPPER FOR EACH INPUT FILE//
	    //empList2.txt will be procedded by MyMapper2
	    MultipleInputs.addInputPath(job, input_dir2, TextInputFormat.class, MyMapper2.class); //WE NEED TO SET SEPARATE MAPPER FOR EACH INPUT FILE//
	    
	    FileOutputFormat.setOutputPath(job,output_dir );
	    output_dir.getFileSystem(job.getConfiguration()).delete(output_dir,true);
		
	    //This piece of code will actually intiate the Job run
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	    
	}
}
