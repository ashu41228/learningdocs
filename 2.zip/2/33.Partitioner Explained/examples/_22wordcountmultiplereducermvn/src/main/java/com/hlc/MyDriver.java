package com.hlc;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.partition.HashPartitioner;

public class MyDriver {
	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {

		Path inputDir = new Path(INPUT_DIR);
		// A directory called result.txt will be created.It is not the file name
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.

		Job job = Job.getInstance();
		job.setJobName("MyWordCountJob");

		job.setNumReduceTasks(3);// causes data to be processed by multiple
									// Reducer,no effect on local mode.
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		job.setJarByClass(MyDriver.class);

		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir, true);

		// setting output key type
		job.setOutputKeyClass(Text.class);
		// if you dont provide this,it assumes Text,and hence error
		job.setOutputValueClass(IntWritable.class);

		// Setting your input and output directory
		FileInputFormat.addInputPath(job, inputDir);
		FileOutputFormat.setOutputPath(job, outputDir);

		// This piece of code will actually initiate the Job run
		boolean success = job.waitForCompletion(true);
		if (success) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}

	}

}
