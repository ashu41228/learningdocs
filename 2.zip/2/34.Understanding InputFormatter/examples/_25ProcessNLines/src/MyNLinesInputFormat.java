import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;


public class MyNLinesInputFormat extends TextInputFormat{ //We need to add Textinputformat class which will be used by the framework to
	public MyNLinesInputFormat() {                        //To create the recordreader object of our userdefined recordReader class so that it can call
	System.out.println("MyNLinesInputFormat()..");        // methods implemented by us with our logic
	}
	@Override
    public RecordReader<LongWritable, Text> createRecordReader(InputSplit split, TaskAttemptContext context) {
		
       System.out.println("MyNLinesInputFormat.createRecordReader(-,-)");
    	return new MyNLinesRecordReader();
    }
}
