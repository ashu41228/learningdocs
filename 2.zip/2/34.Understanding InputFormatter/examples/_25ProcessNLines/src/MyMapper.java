

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text,FloatWritable,Text> {
	/*01
	suraj Yahoo 4Yrs BigData TeamLead
	BTech 89 MITS
	Inter 92 ICSE
	02*/
	MyMapper(){System.out.println("MyMapper()");}
	
	
    //Will be called when map slot executes the program
    public void map(LongWritable key, Text value,Context context) throws java.io.IOException ,InterruptedException
    {
    	System.out.println("MyMapper().map(-,-,-)");
    	String lines = value.toString();
    	System.out.println("Lines"+lines);
    	
        String []data = lines.split("\n"); // size=5 
        
        //EmployeeName and company name
    	String empDetails[]=data[1].split(" "); //5
        
        //3rd and forth Line contains marks
        String btech[]=data[2].split(" ");
        String inter[]=data[3].split(" ");
        
        float avgPercentage=(Float.parseFloat(btech[1])+Float.parseFloat(inter[1]))/2;
        context.write(new FloatWritable(avgPercentage),new Text(empDetails[0]+" "+empDetails[1]));
    }	
}
