import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

//Find EmployeeName,companyName with highest  average percentage in Btech and 12th 
public class MyDriver {
	public static void main(String[] args) throws IOException,
			ClassNotFoundException, InterruptedException {

		Path input_dir = new Path("hdfs://localhost:54310/NLineInputFormat/");
		Path output_dir = new Path("hdfs://localhost:54310/output_data/");

		/* Reads hadoop configuration file,and points to the hadoop cluster */
		Configuration conf = new Configuration();
		//conf.set("mapred.linerecordreader.maxlength", "100");
		// Create an object of Job by specifying conf object
		Job job = new Job(conf, "MyWordCountJob");

		job.setInputFormatClass(MyNLinesInputFormat.class);

		// Set your main class in the jar file that will be created in future
		job.setJarByClass(MyDriver.class);

		job.setMapperClass(MyMapper.class);
		job.setMapOutputKeyClass(FloatWritable.class);
		job.setMapOutputValueClass(Text.class);

		// Setting your input and output directory
		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);
		output_dir.getFileSystem(job.getConfiguration()).delete(output_dir,
				true);

		// This piece of code will actually intiate the Job run
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
