import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.util.LineReader;

public class MyNLinesRecordReader extends RecordReader<LongWritable, Text> {
	// KEYIN k;
	private final int NLINESTOPROCESS = 5;//how many lines to be processes at a time.
	private LineReader lineReader;
	private LongWritable key = new LongWritable();
	private Text value = new Text();
	private long start = 0;
	private long end = 0;
	private long pos = 0;
	private int maxLineLength;

	// 1
	public MyNLinesRecordReader() {
		System.out.println("MyNLinesRecordReader()");
	}

	/*
	 * The most important ones for our discussion are the initialize and
	 * nextKeyvalue functions which we will override. The initialize function
	 * will be called only once for each split so we will do setup in this
	 * function and the nextKeyValue function is called for providing records,
	 * here we will write logic so that we send 3 records in the value instead
	 * of default 1.
	 */
	// 2
	@Override
	public void initialize(InputSplit genericSplit, TaskAttemptContext context)
			throws IOException, InterruptedException {
		System.out.println("MyNLinesRecordReader.initialize(-,-)");

		FileSplit split = (FileSplit) genericSplit;
		final Path filePath = split.getPath();
		Configuration conf = context.getConfiguration();
		//set total number of character to read for each line
		//If user has not defined any value for mapred.linerecordreader.maxlength,
		//then read Integer.MAX_VALUE no of character.
		//If you set this value to 10,then only 10 characters will be read for each line.
		this.maxLineLength =conf.getInt("mapred.linerecordreader.maxlength",
				Integer.MAX_VALUE);
		System.out.println("maxLineLength()==> " + maxLineLength);
		FileSystem fs = filePath.getFileSystem(conf);
		//Starting position of the file, initially  start=0
		start = split.getStart();
		// end=length of split in our case file
		end = start + split.getLength();
		
		System.out.println("start value=" + start);
		System.out.println("end Value=" + end);
		
		//If our file has 200 characters,then start=0,end=200
		
		//Set this to true if you have metadata in the first line,and you want to skip.
		boolean skipFirstLine = false;
		
		//InputStream pointing to split for reading the data.
		FSDataInputStream filein = fs.open(filePath);

		//If start!=0 ,you want to skip first line,so go to start position say 10
		//--start,because index start with 0,so 10 means '9' index.
		 if (start != 0){ skipFirstLine = true; --start; filein.seek(start); }
		
		  //Line reader will read the whole line at a time from inputstream.
		lineReader = new LineReader(filein, conf);

		if (skipFirstLine) {
			// reads one line from the inputStream.
			// 0 the maximum number of bytes to store in this string new text
			// maximum no of bytes to consume.
			
			// returns the length till it encounters \n
			start += lineReader.readLine(new Text(), 0,
					(int) Math.min((long) Integer.MAX_VALUE, end - start));
		}
		this.pos = start;//get the position of next line.
	}

	// 3
	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		System.out.println("MyNLinesRecordReader.getNextKeyValue()");
		//If key ==null assign it with default new object
		/*if (key == null) {
			System.out.println("key=null");
			key = new LongWritable();
		}*/
		//set the value of key,initially 0
		key.set(pos);
		
		//If value==null assign it with default new value
		/*if (value == null) {
			System.out.println("value=null");
			value = new Text();
		}*/
		//Clear the value if it is holding any previous value.
		value.clear();
		
		//defining the terminator which will be used to check if line is over.
		final Text endline = new Text("\n");
		
		int newSize = 0;
		for (int i = 0; i < NLINESTOPROCESS; i++) {
			Text v = new Text();
			while (pos < end) {
				//From currentPosition to End Position read the data till it gets "\n",
				//and store it to v object,return the total size read.
				newSize = lineReader.readLine(v, maxLineLength, Math.max(
						(int) Math.min(Integer.MAX_VALUE, end - pos),
						maxLineLength));
				System.out.println("new Size" + newSize);
				//Get the current content of v,from 0 to its length and add it to value object.
				value.append(v.getBytes(), 0, v.getLength());
				//Also append \n after that to value
				value.append(endline.getBytes(), 0, endline.getLength());
				
				//After the above 2 appends,value object will hold data +\n
				
				//If we dont have any more line break.
				if (newSize == 0) {
					break;
				}
				//Update the current position for next read.
				pos += newSize;
				//If we have read all the character from current Line,break
				if (newSize < maxLineLength) {
					System.out.println("Read Entire line successfully");
					break;
				}
			}
		}
		//IF we have no more line,return false
		if (newSize == 0) {
			key = null;
			value = null;
			System.out.println("is Data Available:false");
			return false;
		} else { //If we have more line to follow
			System.out.println("Is Data Available:true");
			return true;
		}
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		System.out.println("MyNLinesRecordReader.getProgress()");
		float value=0.0f;
		if (start == end) {
			value= 0.0f;
		} else {
			value= Math.min(1.0f, (pos - start) / (float) (end - start));
		}
		System.out.println(value);
		return value;
	}
	
	@Override
	public LongWritable getCurrentKey() throws IOException,
	InterruptedException {
		System.out.println("MyNLinesRecordReader.getCurrentKey():" + key);
		
		return key;
	}
	
	@Override
	public Text getCurrentValue() throws IOException, InterruptedException {
		System.out.println("MyNLinesRecordReader.getCurrentValue():" + value);
		
		return value;
	}

	@Override
	public void close() throws IOException {
		System.out.println("MyNLinesRecordReader.close()");
		if (lineReader != null) {
			lineReader.close();
		}
	}



}
