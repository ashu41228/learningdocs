public class FindTheCaller {

	public void show() {
		System.out.println("Hello How are you");
		StackTraceElement[] stackTraceElements = Thread.currentThread()
				.getStackTrace();

		for (StackTraceElement element : stackTraceElements)
			System.out.println(element);
	}

	public void display() {
		show();
	}

	public void test() {
		display();
	}

	public static void main(String[] args) {
		new FindTheCaller().test();
	}
}
