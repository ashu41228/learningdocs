package com.hlc;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();

	public MyMapper() {
		System.out.println("MyMapper()");
	}

	// called once for each split at the beginning
	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		System.out.println("MyMapper.setup(-)");
	}

	// called once for each record.
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		System.out.println("map(-,-,-)");

		/*StackTraceElement[] stackTraceElements = Thread.currentThread()
				.getStackTrace();
		System.out.println("Analysing caller...");
		for (StackTraceElement element : stackTraceElements)
			System.out.println(element);*/

		System.out.println("Key= " + key + " Value= " + value + " Context="
				+ context);

		StringTokenizer itr = new StringTokenizer(value.toString());
		while (itr.hasMoreTokens()) {
			word.set(itr.nextToken());
			context.write(word, one);
		}
	}

	// called once for each split at the end
	@Override
	protected void cleanup(Context context) {
		// super.cleanup(context);
		System.out.println("MyMapper.cleanup(-)");
	}

	@Override
	public void run(Context context) throws IOException, InterruptedException {
		// Mapper generates ouput only when super.run() is called,otherwise you
		// will have to manually
		// manange calling setup,cleanup,map()
		System.out.println("MyMapper.run(-)");
		super.run(context);
	}

}
