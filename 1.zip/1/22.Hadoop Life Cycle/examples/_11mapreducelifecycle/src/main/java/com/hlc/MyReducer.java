package com.hlc;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	MyReducer() {
		System.out.println("MyReducer()");
	}

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		System.out.println("MyReducer.setUp(-)");
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {

		System.out.println("MyReducer.cleanup(-)");
	}

	@Override
	public void run(Context context) throws IOException, InterruptedException {
		// Reducer output will be generated when super.run() is executed
		// Else you will have to call setup,cleanup,reduce() manually.
		System.out.println("MyReducer.run(-)");
		super.run(context);
	}

	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		System.out.println("reduce(-,-,-)");

		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		System.out.println("Analysing caller...");
		for (StackTraceElement element : stackTraceElements)
			System.out.println(element);

		System.out.println(" context= " + context);

		System.out.println("key=" + key);
		System.out.print("All values=");

		int sum = 0;
		for (IntWritable value : values) {
			System.out.print(" " + value.get());
			sum += value.get();
		}
		System.out.println();
		context.write(key, new IntWritable(sum));
	}
}
