package com.hlc;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {

	private static final String INPUT_DIR="hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR="hdfs://localhost:9000/output_data/";
	private static boolean flag;
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Path input_dir=new Path(INPUT_DIR);
	    Path output_dir=new Path(OUTPUT_DIR);
		
	    MyIOUtil.uploadInputFile(INPUT_DIR);//Our class to upload the data.
	    
		/*Reads hadoop configuration file,and points to the hadoop cluster*/
		Configuration conf = new Configuration();
		
		//Create an object of Job by specifying conf object
		Job job = Job.getInstance(conf, "MyWordCountJob");
		
		//Set your main class in the jar file that will be created in future
	    job.setJarByClass(MyDriver.class);
	    
	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);
	    
	    //setting output key type
	    job.setOutputKeyClass(Text.class);
	    //if you dont provide this,it assumes Text,and hence error
	    job.setOutputValueClass(IntWritable.class);
	    
	    //Setting your input and output directory
	    FileInputFormat.addInputPath(job, input_dir);
	    FileOutputFormat.setOutputPath(job,output_dir );
	    
	    output_dir.getFileSystem(conf).delete(output_dir, true);
	    
	    //This piece of code will actually intiate the Job run
	    flag = job.waitForCompletion(true);//returns true for normal execution
	    
	    if(flag){
	    	MyIOUtil.readOutputFile(OUTPUT_DIR);
	    }
	    
	}
}
