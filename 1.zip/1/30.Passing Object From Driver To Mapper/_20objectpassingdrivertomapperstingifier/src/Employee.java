import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class Employee implements Writable {

	private Text empName;
	private IntWritable empAge;
	private FloatWritable empSalary;

	public Employee() {
		System.out.println("Employee()");

		// Initialize all,API uses this method while deserializing.If you dont
		// initialize it here,it holds null and readIn() will cause
		// nullPointerException
		empName = new Text();
		empAge = new IntWritable();
		empSalary = new FloatWritable();
	}

	public Employee(Text empName, IntWritable empAge, FloatWritable empSalary) {
		System.out.println("Employee(-,-,-)");
		this.empName = empName;
		this.empAge = empAge;
		this.empSalary = empSalary;
	}

	public Text getEmpName() {
		System.out.println("Employee.getEmpName()");
		return empName;
	}

	public IntWritable getEmpAge() {
		System.out.println("Employee.getEmpAge()");

		return empAge;
	}

	public FloatWritable getEmpSalary() {
		System.out.println("Employee.getEmpSalary()");

		return empSalary;
	}

	public void setEmpName(Text empName) {
		System.out.println("Employee.setEmpName(-)");

		this.empName = empName;
	}

	public void setEmpAge(IntWritable empAge) {
		System.out.println("Employee.setEmpAge(-)");

		this.empAge = empAge;
	}

	public void setEmpSalary(FloatWritable empSalary) {
		System.out.println("Employee.setEmpSalary(-)");

		this.empSalary = empSalary;
	}

	@Override
	public void write(DataOutput out) throws IOException {

		System.out.println("Employee.write(-)");
		empName.write(out);
		empAge.write(out);
		empSalary.write(out);

	}

	@Override
	public void readFields(DataInput in) throws IOException {
		System.out.println("Employee.readFields(-)");

		empName.readFields(in);
		empAge.readFields(in);
		empSalary.readFields(in);
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName.toString() + ", empAge="
				+ empAge.toString() + ", empSalary=" + empSalary.toString()
				+ "]";
	}
	/*
	 * @Override public boolean equals(Object o) {
	 * System.out.println("Employee.equals(-)"); if (!(o instanceof Employee))
	 * return false; Employee other = (Employee) o; return
	 * (empName.toString().equals(other.toString()) &&
	 * empAge.toString().equals(other.empAge.toString()) &&
	 * empSalary.toString().equals(other.empSalary.toString()));
	 * 
	 * }
	 */
}
