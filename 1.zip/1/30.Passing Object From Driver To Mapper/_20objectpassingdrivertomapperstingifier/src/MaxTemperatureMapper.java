import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DefaultStringifier;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MaxTemperatureMapper  extends Mapper<LongWritable, Text, Text, IntWritable> {
	 private Employee emp=null;
	@Override
	protected void setup(Context context)throws IOException, InterruptedException {
		  System.out.println("MaxTemperatureMapper.setUp(-)");
		  Configuration conf=context.getConfiguration();
		  System.out.println("conf Object"+conf);
		  String empString=conf.get("empObj");
		  DefaultStringifier<Employee> str=new DefaultStringifier<Employee>(conf, Employee.class);
		  
		  emp=(Employee)str.fromString(empString);
		 str.close();
		 System.out.println("Mapper.setUp(-):Employee ="+emp);
		 System.out.println("Employee hashCode:"+emp.hashCode());
	}
	//1901 32
	  @Override  public void map(LongWritable key, Text value, Context context)throws IOException, InterruptedException 
	  {
		  System.out.println("MaxTemperatureMapper.map(-,-,-)");
		  String data[]=value.toString().split(" ");
		 
		 context.write(new Text(data[0]), new IntWritable(Integer.parseInt(data[1])));
	  }
	  
	  @Override
	protected void cleanup(Context context)
			throws IOException, InterruptedException {
			
		}
}
	 