import java.io.DataOutput;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DefaultStringifier;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MaxTemperatureDriver {
	public static void main(String[] args) throws Exception {
		
		Path input_dir=new Path("hdfs://localhost:54310/temp_data/");
	    Path output_dir=new Path("hdfs://localhost:54310/tmp_output/");
		
	    Job job = new Job();
		
		Configuration conf=job.getConfiguration();
		System.out.println("conf Object"+conf);
		//conf.set("io.serializations","org.apache.hadoop.io.serializer.WritableSerialization");

		Employee emp=new Employee(new Text("Prasad"), new IntWritable(25), new FloatWritable(5000));
		System.out.println("Employee hashCode:"+emp.hashCode());
		
		DefaultStringifier<Employee> stringfier=new DefaultStringifier<Employee>(conf, Employee.class);
		String empStr=stringfier.toString(emp);
		
		System.out.println("Serialization done"+empStr);
		stringfier.close();
		conf.set("empObj", empStr);
		
		job.setJarByClass(MaxTemperatureDriver.class);
		job.setJobName("Max temperature");
		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);
		job.setMapperClass(MaxTemperatureMapper.class);
		job.setReducerClass(MaxTemperatureReducer.class);
		//job.setNumReduceTasks(1);
		//Reducer code gets executed only at one place,combiner gets executed for all other case
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		output_dir.getFileSystem(job.getConfiguration()).delete(output_dir,true);
			
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
