package com.hlc;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

public class MaxTemperatureCombiner extends Reducer<Text, IntWritable, Text, IntWritable> {
	private static final Logger LOGGER = Logger.getLogger(MaxTemperatureCombiner.class);

	public MaxTemperatureCombiner() {
		LOGGER.info("MaxTemperatureCombiner()");
	}

	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		LOGGER.info("MaxTemperatureCombiner.reduce()");
		LOGGER.info("Key=" + key);
		LOGGER.info("Values...");
		int maxValue = Integer.MIN_VALUE;
		for (IntWritable value : values) {
			LOGGER.info("" + value.get());
			maxValue = Math.max(maxValue, value.get());
		}
		context.write(key, new IntWritable(maxValue));
	}
}
