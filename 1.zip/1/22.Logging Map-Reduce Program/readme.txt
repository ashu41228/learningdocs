In Log4j,you can write the message in 5 types.

ALL < DEBUG < INFO < WARN < ERROR < FATAL < OFF

IN logger.property file if we have set ALL then debug,info,warn,error,fatal will be printed
IN logger.property file if we have set INFO then INFO,warn,error,fatal will be printed 
IN logger.property file if we have set WARN then warn,error,fatal will be printed 
please understand above pattern

We need to Add Log4j.property file in our maven project.once you add this file it mean your program's logging facality is enabled.
LOGGER = Logger.getLogger(A.class); it will create the logger object
then we can use LOGGER.INFO/debug/fatal/warn("message") in code to print our message; 

If In property file, if the setting is WARN,then only WARN,ERROR,FATAL logs will be captured
If in the propery file,if the setting is ERROR,then only ERROR and FATAL will be captured.

Appender tells where the output should go
ie File,Console etc..
if you have set the appender to file then it will throw output to file or vice versa
  
org.apache.log4j.FileAppender --> to throw the log to file
org.apache.log4j.ConsoleAppender --> to throw the log to a console
org.apache.log4j.DailyRollingFileAppender

See the list of all appender.
https://logging.apache.org/log4j/1.2/apidocs/org/apache/log4j/Appender.html



Mapper:
LOGGER.debug(1)
...
LOGGER.debug(2)
....
LOGGER.debug(3)
.....
try{
...
}
catch(Exception e)
{
LOGGER.error("Exception occured:"+e.printStackTrace())

}





