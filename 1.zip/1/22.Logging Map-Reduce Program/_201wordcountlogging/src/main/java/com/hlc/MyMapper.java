package com.hlc;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	private static final Logger LOGGER = Logger.getLogger(MyMapper.class);

	public MyMapper() {
		LOGGER.info("MyMapper():" + hashCode());
	}
	// Sample data
	// raja kisan prakash kiran dinesh

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();

	// Will be called when map slot executes the program
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		LOGGER.info("map(-,-,-)");
		LOGGER.info("Key= " + key + " Value= " + value + " Context=" + context);

		StringTokenizer itr = new StringTokenizer(value.toString());
		while (itr.hasMoreTokens()) {
			word.set(itr.nextToken());
			context.write(word, one);
		}
	}
}
