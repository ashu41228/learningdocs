package com.hlc;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

public class MyReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	private static final Logger LOGGER = Logger.getLogger(MyReducer.class);

	public MyReducer() {
		LOGGER.info("MyReducer().hashCode=" + hashCode());
	}

	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		LOGGER.info("reduce(-,-,-)");
		LOGGER.info(" context= " + context);

		LOGGER.info("key=" + key);
		LOGGER.info("All values=");

		int sum = 0;
		for (IntWritable value : values) {
			LOGGER.info(" " + value.get());
			sum += value.get();
		}
		context.write(key, new IntWritable(sum));
	}
}
