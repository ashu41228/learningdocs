package p1;



import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, IntWritable, Text> {
  
	@Override
		protected void setup(Context context) throws IOException{
			/*
			 * Default size of Distributed Cache is 10 GB,We can control the size of
			 * the distributed cache by explicitly defining its size in hadoop’s
			 * configuration file local.cache.size.
			 */
			/*
			 * Thus, Distributed cache is a mechanism to caching readonly data over
			 * Hadoop cluster. The sending of readOnly files occurs at the time of
			 * job creation and the framework makes the cached files available to
			 * the cluster nodes at their computational time.
			 */

			System.out.println("MyMapper.setUp(-,-,-,-)");
			Path[] uris = DistributedCache.getLocalCacheFiles(context.getConfiguration());
			System.out.println("Total Files =" + uris.length);

			for (int i = 0; i < uris.length; i++) {
				String fileName=uris[i].toString();
				//use fileName.contains("mydata") to check the filename
			
					System.out.println("Content of"+fileName);
					Scanner scan = new Scanner(new FileReader(fileName));
					while(scan.hasNext()){
						System.out.println(scan.next());
					}
					scan.close();
			}
		}
  //mahesh,980,SMCS,Orissa,mahesh@gmail.com
	//0     1    2    3		4
     //called once for each record.
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
      {
    	String data=value.toString().trim().toLowerCase();
    	if(data.length()==0)return;
    	    	
    	
    	//each record contains data in mahesh,980,SMCS,Orissa,mahesh@gmail.com format
    	String arr[]=value.toString().split(",");
    	
    	IntWritable marks=new IntWritable(Integer.parseInt(arr[1]));
    	Text details=new Text(arr[0]+","+arr[2]+","+arr[3]);
    	
    	
        context.write(marks, details);//key we are using same,so that they can be grouped together
      
        }
}