package p1;


import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
	
	public static void main(String[] args) throws Exception {

		Path input_dir = new Path("hdfs://localhost:54310/student_marks");
		Path output_dir = new Path("hdfs://localhost:54310/output_data");
				
		Configuration conf = new Configuration();
		conf.set("fs.default.name", "hdfs://localhost:54310");
		conf.set("mapred.job.tracker", "localhost:54311");
		    
		//create your own jar of the project,store in in local location and specify that location.
		//This is needed for distributed run
		conf.set("mapred.jar","/home/hduser/MyDistributedCacheJar.jar");//Create the jar of your own project and specify it here
			     
		DistributedCache.addCacheFile(new URI("/myapp/mydata.txt"), conf);
		DistributedCache.addCacheFile(new URI("/myapp/mydriver.properties"), conf);
		
		Job job = new Job(conf, "MyDistributedCacheExample");
		job.setJarByClass(MyDriver.class);
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		
		// delete the output files at every run
		output_dir.getFileSystem(job.getConfiguration()).delete(output_dir,
				true);

		// specifying reducers output value
		// if you dont provide this,it assumes LongWritable,and then error
		job.setOutputKeyClass(IntWritable.class);
		// if you dont provide this,it assumes Text,and hence error
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);
		
		// This piece of code will actually intiate the Job run
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
