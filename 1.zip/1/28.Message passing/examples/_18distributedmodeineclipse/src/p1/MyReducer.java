package p1;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,IntWritable,Text,IntWritable> {

	//apple [1,1,1]
	
	@Override
	protected void reduce(Text word, Iterable<IntWritable> arr,
			Context ctx)throws IOException, InterruptedException {
		System.out.println(word.toString()+"::");
		Iterator it=arr.iterator();
		int count=0;
		while(it.hasNext())
		{
			IntWritable i=(IntWritable)it.next();
			count=count+i.get();
			System.out.println(i.get());
		}
		
		ctx.write(word,new IntWritable(count));
		
	}
}
