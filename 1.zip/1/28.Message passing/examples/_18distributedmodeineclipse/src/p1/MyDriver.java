package p1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
	//Create a configuration class pointing to default configuration
	Configuration conf =new Configuration();
	conf.set("fs.default.name", "hdfs://localhost:54310");
	conf.set("mapred.job.tracker", "localhost:54311");
	    
	//create your own jar of the project,store in in local location and specify that location.
	//This is needed for distributed run
	conf.set("mapred.jar","/home/hduser/MyWC2.jar");//Create the jar of your own project and specify it here
		
	//Prepare a Job object
	Job job = new Job(conf, "MyWordCountJob");
	
	//Link your driver class with the job
	job.setJarByClass(MyDriver.class);
	
	//Link Mapper with job
	job.setMapperClass(MyMapper.class);
	
	//Link reducer with job
	job.setReducerClass(MyReducer.class);
	
	//Set Final Output Key
    job.setOutputKeyClass(Text.class);
    
  //Set Final Output value
    job.setOutputKeyClass(IntWritable.class);
    
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(IntWritable.class);
    //Define Input Path
    Path input_dir=new Path("hdfs://localhost:54310/input_data/");
    FileInputFormat.addInputPath(job, input_dir);
  
    //Add output path to your Job
    Path output_dir=new Path("hdfs://localhost:54310/output_data/");
    FileOutputFormat.setOutputPath(job,output_dir );
    
    output_dir.getFileSystem(conf).delete(output_dir, true);
    //Run Your Program
    //boolean flag= job.waitForCompletion(true);
    System.exit(job.waitForCompletion(true) ? 0 : 1);
}
}
