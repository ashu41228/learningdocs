

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, IntWritable, Student> {
   String stateName;
	@Override
		protected void setup(Context context){
			Configuration conf=context.getConfiguration();
			stateName=conf.get("stateName");
			conf.set("fromMapper", "Hello");
			
		}
  //mahesh,980,SMCS,Orissa,mahesh@gmail.com
	//0     1    2    3		4
     //called once for each record.
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
      {
    	String currentLine=value.toString().trim().toLowerCase();
    	if(currentLine.isEmpty())return;
    	
    	String arr[]=currentLine.split(",");
    	if(arr.length<5) return;
    	
    	if(!(arr[3]).equals(stateName)) return;
    	
    	System.out.println("Processing Line:"+currentLine);
    	//each record contains data in mahesh,980,SMCS,Orissa,mahesh@gmail.com format
    	//String arr[]=data.split(",");
    	
    	Text studentName=new Text(arr[0]);
    	IntWritable marks=new IntWritable(Integer.parseInt(arr[1]));
    	Text schoolName=new Text(arr[2]);
    	Text state=new Text(stateName);
    	
    	System.out.println("Marks="+marks);
    	Student student=new Student(studentName,marks,schoolName,state);    	
    	
        context.write(marks, student);
        System.out.println("Mapper Ouput:"+marks+" "+student);
        }
}