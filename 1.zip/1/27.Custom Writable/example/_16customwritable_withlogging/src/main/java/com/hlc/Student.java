package com.hlc;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.log4j.Logger;

public class Student implements Writable {
	private static final Logger LOGGER = Logger.getLogger(Student.class);

	private Text studentName;
	private Text schoolName;
	private Text cityName;

	// done
	public Student() {
		LOGGER.debug("Student()");
		this.studentName = new Text();
		this.schoolName = new Text();
		this.cityName = new Text();
	}

	public Student(Text studentName, Text schoolName, Text cityName) {
		LOGGER.debug("Student(-,-,-,-)");
		this.studentName = studentName;
		this.schoolName = schoolName;
		this.cityName = cityName;
	}

	// deep copy constructor
	public Student(Student st) {
		this.studentName = new Text(st.studentName);
		this.schoolName = new Text(st.schoolName);
		this.cityName = new Text(st.cityName);
	}

	@Override //This will be printed in the final output
	public String toString() {
		return studentName + "," + schoolName;
	}

	@Override
	public void write(DataOutput out) throws IOException {

		LOGGER.debug("Student.write(-)");
		LOGGER.debug(studentName);
		studentName.write(out);
		schoolName.write(out);
		cityName.write(out);
	}

	// done
	@Override
	public void readFields(DataInput in) throws IOException {
		LOGGER.debug("Student.readFields(-)");
		LOGGER.debug(studentName);
		studentName.readFields(in);
		schoolName.readFields(in);
		cityName.readFields(in);
	}

	@Override
	public int hashCode() {
		return studentName.hashCode();
	}
}
