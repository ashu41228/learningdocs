package com.hlc;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

public class MyMapper extends Mapper<LongWritable, Text, IntWritable, Student> {
	private static final Logger LOGGER = Logger.getLogger(MyMapper.class);

	// mahesh,980,SMCS,Orissa,mahesh@gmail.com
	// 0 1 2 3 4
	// called once for each record.
	public void map(LongWritable key, Text line, Context context) throws IOException, InterruptedException {
		String currentLine = line.toString().trim();
		// skip empty lines
		if (currentLine.isEmpty())
			return;

		// each record contains date in this format
		// mahesh,980,SMCS,Orissa,mahesh@gmail.com
		String studData[] = currentLine.split(",");

		if (studData.length != 5)
			return;

		Text studentName = new Text(studData[0]);
		IntWritable marks = new IntWritable(Integer.parseInt(studData[1]));
		Text schoolName = new Text(studData[2]);
		Text state = new Text(studData[3]);

		LOGGER.debug("Marks=" + marks);
		Student student = new Student(studentName, schoolName, state);

		context.write(marks, student);// key we are using same,so that they can
										// be grouped together
		LOGGER.debug("Mapper Ouput:" + marks + " " + student);
	}
}