package com.hlc;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

public class MyReducer extends
		Reducer<IntWritable, Student, IntWritable, Student> {
	private static final Logger LOGGER = Logger.getLogger(MyReducer.class);

	private ArrayList<Student> topScorerList;
	private int topScore = 0;

	protected void setup(Context context) throws IOException,
			InterruptedException {

		topScorerList = new ArrayList<>();
		LOGGER.debug("MyReducer.setup(-,-)");
	}

	/*
	 * 900 student1 900 student2, 900 student3.....
	 * 
	 * 900 [student1,student2,student3]
	 */

	@Override
	public void reduce(IntWritable currentMark, Iterable<Student> values,
			Context context) throws IOException, InterruptedException {

		LOGGER.debug("key=" + currentMark);
		System.out.print("All values=");
		
		int mark=currentMark.get();

		if (mark > topScore) {
			topScore = mark;

			if (!topScorerList.isEmpty()) {
				topScorerList.clear();// clear all element from arrayList
			}

			for (Student st : values) {
				LOGGER.debug("topScorer:" + st);

				// Dont directly add object to the List,Map-reduce will copy all
				// same instance to the Object and we certainly dont need the
				// dupicate object
				// use deep copy constructor concept and create new object and
				// then store it
				// dont get fooled by the size
				Student st1 = new Student(st);
				topScorerList.add(st1);
			}
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException,
			InterruptedException {
		LOGGER.debug("MyReducer.cleanup(-)");

		for (Student st : topScorerList) {
			LOGGER.debug(st);
			// Use mos to store result in resultant file
			context.write(new IntWritable(topScore), st);
		}
	}
}