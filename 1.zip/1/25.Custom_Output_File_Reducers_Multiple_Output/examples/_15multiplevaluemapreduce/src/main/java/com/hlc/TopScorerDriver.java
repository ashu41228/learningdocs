package com.hlc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class TopScorerDriver {
	// inputdata contains students details
	// studentname,studentmarks,student_schoolname,city
	// We need to find out the highest mark as well as the details of the
	// student
	// There are two ways,in the value as singlekey,you append all the
	// strings,or use a Custom class implementing Writable that can act as a
	// Value
	
	private static final String INPUT_DIR = "hdfs://localhost:9000/student_marks";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws Exception {

		Path input_dir = new Path(INPUT_DIR);
		Path output_dir = new Path(OUTPUT_DIR);
		
		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.

		Configuration conf = new Configuration();

		Job job = Job.getInstance(conf, "TopScorerJob");
		job.setJarByClass(TopScorerDriver.class);
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		//job.setNumReduceTasks(0);//Runs the Map only job
		
		
		// delete the output files at every run
		output_dir.getFileSystem(job.getConfiguration()).delete(output_dir,
				true);

		// specifying reducers output value
		// if you dont provide this,it assumes LongWritable,and then error
		job.setOutputKeyClass(IntWritable.class);
		// if you dont provide this,it assumes Text,and hence error
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);
		// job.setNumReduceTasks(0);
		// This piece of code will actually initiate the Job run
		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution

		if (flag) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}
	}
}
