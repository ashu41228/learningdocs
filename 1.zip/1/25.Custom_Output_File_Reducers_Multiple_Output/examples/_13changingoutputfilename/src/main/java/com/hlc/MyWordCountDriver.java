package com.hlc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyWordCountDriver {
	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";

	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data/result.txt";

	public static void main(String[] args) throws Exception {

		Path input_dir = new Path(INPUT_DIR);
		// A directory called result.txt will be created.It is not the file name
		Path output_dir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.

		Configuration conf = new Configuration();

		Job job = Job.getInstance(conf, "MyWordCountJob");
		job.setJarByClass(MyWordCountDriver.class);
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		// job.setNumReduceTasks(10);

		// specifying reducers output value
		// if you dont provide this,it assumes LongWritable,and then error
		job.setOutputKeyClass(Text.class);
		// if you dont provide this,it assumes Text,and hence error
		job.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);
		output_dir.getFileSystem(conf).delete(output_dir, true);
		// This piece of code will actually intiate the Job run
		boolean flag = job.waitForCompletion(true);// returns true for normal
													// execution

		if (flag) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}
	}
}
