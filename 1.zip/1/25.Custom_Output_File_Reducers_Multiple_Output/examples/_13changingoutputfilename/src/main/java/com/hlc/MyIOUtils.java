package com.hlc;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

public class MyIOUtils {

	public static void main(String[] args) throws IOException {
		uploadInputFile("hdfs://localhost:9000/input_data");
	}

	public static void uploadInputFile(String inputPath) throws IOException {
		String localPath = "src/main/resources/";
		String[] fileNameList = { "fruit&Sports1.txt", "fruit&Sports2.txt" };

		Path inputHdfsPath = new Path(inputPath);
		Configuration conf = new Configuration();
		// Pointer to HDFS
		FileSystem fs = FileSystem.get(URI.create(inputPath), conf);
		fs.delete(inputHdfsPath, true);//first empty the input_folder

		for (String fileName : fileNameList) {
			InputStream in = new BufferedInputStream(new FileInputStream(localPath + fileName));
			// Create a file called fruit1.txt in hdfs and will be reference by
			// out
			String destPath=inputPath+"/"+fileName;
			OutputStream out = fs.create(new Path(destPath));
			IOUtils.copyBytes(in, out, 4096, true);
			
			System.out.println("Created :"+destPath);
			
		}
	}
	
	public static void readOutputFile(String output) throws IOException{

		String url = output+"/fruits_sports.txt-r-00000";
		Configuration conf = new Configuration();

		FileSystem fs = FileSystem.get(URI.create(url), conf);
		FSDataInputStream in = fs.open(new Path(url));
		System.out.println("***********************Output*******************");
		IOUtils.copyBytes(in, System.out, 4096, false);
	}
}
