package com.hlc;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.log4j.Logger;

public class MaxTemperaturePartitioner extends Partitioner<Text, IntWritable> {
	private static final Logger LOGGER = Logger.getLogger(MaxTemperatureMapper.class);

	public MaxTemperaturePartitioner() {
		LOGGER.info("MaxTemperaturePartitioner()");
	}

	@Override
	public int getPartition(Text key, IntWritable value, int numReduceTasks) {
		// Default logic of HashPartitioner
		// return (key.hashCode() & Integer.MAX_VALUE) % numReduceTasks;
		LOGGER.info(key.hashCode() + ":" + Integer.MAX_VALUE + ":" + numReduceTasks);

		LOGGER.info("MaxTemperaturePartioner.getPartition(-,-,-)");

		LOGGER.info(key + ":: " + value + ":" + numReduceTasks);

		if (Integer.parseInt(key.toString()) % 2 == 0)
			return 0;
		else
			return 1;

	}

}
