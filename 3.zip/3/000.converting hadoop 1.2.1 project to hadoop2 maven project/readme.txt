You might have observed,while in class I am teaching you through the Maven Project,
But sometime in the source code that is shared with you,you are required to convert it to Maven project.

Why?
To help you understand the Java project structure better.Once you are familiar with it.
It will hardly take 5 minutes to convert the project to Maven.

Steps:
--------
1.Import my Old projects into Eclipse using import->Existing project into workspace.
2.Rename the old project from _22WordCount  to _22WordCount_Old
3.Create a new Maven Project with the same name as of the original project(_22WordCount)
4.goto pom.xml and extend it from parent project.Please check other project's pom.xml for this.
5.Copy the log4j.properties in src/main/resources
6.copy the input directory from _22WordCount_Old to src/main/resources/input_data
7.copy the MyIOUtils.java from other Maven project to this maven project
8.Make your changes in the Driver program accordingly,which includes 
   the ports of hadoop2 while configuring input and output file path
   Using MyIOUtils for automatic uploading the input files
   Using MyIOUtils for reading the part-r-00000 once the program is over.
9.Also make sure you replace all the System.out.println with the LOGGER.info
10.Make sure to solve all the sonar issues.

For reference I have kept a project 
_23MaxTemperatureCustomPartitioner_old   --> Hadoop 1.2.1 project
_23MaxTemperatureCustomPartitioner_mvn   --> Hadoop 2.x Maven Based
