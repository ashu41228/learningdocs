package com.hlc;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	private Text outputKey = new Text();

	@Override
	public void map(LongWritable inputKey, Text inputVal, Context context) throws IOException, InterruptedException {
		String line = inputVal.toString();
		String[] a = line.split("\\W+");

		for (int i = 0; i < a.length - 1; i++) {
			outputKey.set(a[i] + " " + a[i + 1]);
			context.write(outputKey, new IntWritable(1));
		}
	}
}