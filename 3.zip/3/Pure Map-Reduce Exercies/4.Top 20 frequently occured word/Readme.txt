Find the wordcount of top 20 words
------------------------------------

We need to write a Map-reduce program that will do the word count of the bible1.txt, bible2.txt, bible3.txt.
& displays wordcount of top 20 repeated words.

For 3 files,we will get 3 blocks(b1,b2,b3) as they are under the block size(128 MB)

b1
b2
b3

3 Mappers will be used parallely to process this dataset,and it will result in a lot of (word,1) to the reducer.
We will write our combiner,so that it calculates total occurance of word in that local node say (word,10)
And very less amount of data will travel to the Reducer.
The reducer will again aggregate the count and will store it in HashMap.
Please make sure not to count the space.

You may need to use hashMap in the reducer code,to keep check on top twently high frequency words,
But dont hold everything in the hashMap.
You should dynamically hold only 20 high frequency words...All low freqency word should be deleted as we discover high freqency words.

For the first 20 words,simple add them in the Map.
But when we encounter 21st word,you need to find out the word from the HashMap with least occurance(out of 20),
check if the 21st word's frequency is greater than the word with least occurance.
If yes, remove that and put the new one.
else, dont remove the word.

At the end of the day,you should end up with the below output.
================================================================
and 		12846
i 			8854
god 		4114
israel 		2574
the 		1843
for 		1743
but 		1558
then 		1374
lord 		1071
o 			1066
david 		1064
jesus 		978
moses 		847
judah 		816
jerusalem 	814
he 			754
now 		643
so 			622
egypt 		611
behold 		596