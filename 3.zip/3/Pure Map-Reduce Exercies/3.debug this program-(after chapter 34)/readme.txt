Please find out the root cause of the problem.
java.lang.Exception: java.lang.NumberFormatException: For input string: "m"
	at org.apache.hadoop.mapred.LocalJobRunner$Job.runTasks(LocalJobRunner.java:462)
	at org.apache.hadoop.mapred.LocalJobRunner$Job.run(LocalJobRunner.java:522)