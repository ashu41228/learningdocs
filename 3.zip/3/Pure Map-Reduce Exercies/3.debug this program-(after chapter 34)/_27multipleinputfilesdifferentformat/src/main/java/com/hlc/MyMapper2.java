package com.hlc;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;
//Will Process
/*
201,Ram,m,10000,26
202,kumar,m,30000,31
203,sheetal,f,6000,21
204,sabina,f,90000,26
205,shyam,m,10000,24
206,laxmi,f,10000,25
207,suraz,m,30000,28
*/
public class MyMapper2 extends Mapper<LongWritable, Text, Text, IntWritable> {
	private static final Logger LOGGER = Logger.getLogger(MyMapper1.class);

	public void map(LongWritable offset, Text value, Context con) throws IOException,
			InterruptedException {
		LOGGER.info("MyMapper2.map(-,-,-)"+value.toString());
		String line = value.toString();
		String[] words = line.split(",");
		String gender = words[2];
		int salary= Integer.parseInt(words[3]);
		LOGGER.info(gender+"::"+salary);
		con.write(new Text(gender), new IntWritable(salary));
	}
}