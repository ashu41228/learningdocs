package com.hlc;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

//Find EmployeeName,companyName with highest  average percentage in Btech and 12th 
public class MyDriver {
	private static final String INPUT_DIR1 = "hdfs://localhost:9000/emp_data/empList1.txt";
	private static final String INPUT_DIR2 = "hdfs://localhost:9000/emp_data/empList2.txt";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {

		Path inputDir1 = new Path(INPUT_DIR1);
		Path inputDir2 = new Path(INPUT_DIR2);
		// A directory called result.txt will be created.It is not the file name
		Path outputDir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR1);// Our class to upload the data.
		MyIOUtils.uploadInputFile(INPUT_DIR2);// Our class to upload the data.

		Job job = Job.getInstance();
		job.setJobName("Multiple Input Files Different Output");

		// Set your main class in the jar file that will be created in future
		job.setJarByClass(MyDriver.class);
		job.setMapperClass(MyMapper1.class);
		job.setMapperClass(MyMapper2.class);

		job.setReducerClass(MyReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);

		// Setting your input and output directory
		// empList1.txt will be processed by MyMapper1
		MultipleInputs.addInputPath(job, inputDir1, TextInputFormat.class, MyMapper1.class);
		// empList2.txt will be procedded by MyMapper2
		MultipleInputs.addInputPath(job, inputDir2, TextInputFormat.class, MyMapper2.class);

		FileOutputFormat.setOutputPath(job, outputDir);
		outputDir.getFileSystem(job.getConfiguration()).delete(outputDir, true);

		// This piece of code will actually initiate the Job run
		boolean success = job.waitForCompletion(true);
		if (success) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}

	}
}
