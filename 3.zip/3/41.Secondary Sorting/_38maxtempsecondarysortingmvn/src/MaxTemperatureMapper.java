import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MaxTemperatureMapper extends Mapper<LongWritable, Text, Text, Text> {

	public MaxTemperatureMapper() {
		System.out.println("MaxTemperatureMapper()");
	}

	/*
	 * 1901 34:A 1903 71:A 1901 20:B 1903 72:B
	 */
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String data[] = value.toString().split(" ");

		String year = data[0];
		String tempCity = data[1]; // 34:A

		String tempCityArr[] = tempCity.split(":");

		String temp = tempCityArr[0];
		String city = tempCityArr[1];

		System.out.println("MaxTemperatureMapper.map(-,-,-):" + data[0] + " " + data[1]);
		context.write(new Text(year + " " + temp), new Text(year + " " + temp + ":" + city));
	}
}
