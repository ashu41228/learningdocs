
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MaxTemperatureReducer extends
		Reducer<Text, Text, NullWritable, Text> {
	public MaxTemperatureReducer(){
		System.out.println("MaxTemperatureReducer()");
	}
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		System.out.println("MaxTemperatureReducer.reduce(-,-,-)");
		System.out.println("Key="+key);
		
		values.forEach( text->{
			System.out.println();
			try {
				context.write(NullWritable.get(), text);
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
	}
}
