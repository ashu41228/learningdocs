

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, IntWritable, Text> {
        
    //mahesh,980,SMCS,Orissa,mahesh@gmail.com
	//  0     1    2    3		4
    //called once for each record.
    public void map(LongWritable key, Text line, Context context) throws IOException, InterruptedException
      {
    	
    	String currentLine=line.toString().trim();
    	//skip empty lines
    	if(currentLine.isEmpty())return ;
    	
    	//each record contains date in this format
    	//mahesh,980,SMCS,Orissa,mahesh@gmail.com
    	String studData[]=currentLine.split(",");
    	
    	String studentName=studData[0];
    	int mark=Integer.parseInt(studData[1]);
    	String schoolName=studData[2];
    	String state=studData[3];
    	//mahesh,SMCS,Orissa
    	String value=studentName+","+schoolName+","+state;
    	
    	System.out.println("Mapper Output="+mark+":::"+value);
    	
    	//980   mahesh,SMCS,Orissa
        context.write(new IntWritable(mark),new Text(value));//key we are using same,so that they can be grouped together
        
        }
}