import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class MyKeyComparator  extends WritableComparator{
//Super class doesnot have default constructor
	protected MyKeyComparator() {
		super(IntWritable.class,true);//second parameter will start the buffer,if you dont provide this value,it throws NullPOinterException
		System.out.println("MyKeyComparator()");
		
	}
	@Override
		public int compare(WritableComparable m1, WritableComparable m2) {
		int mark1=((IntWritable)m1).get();
		int mark2=((IntWritable)m2).get();
		return -(mark1-mark2);
		
		//return (year1-year2);//default Implementation
		}
}
	 