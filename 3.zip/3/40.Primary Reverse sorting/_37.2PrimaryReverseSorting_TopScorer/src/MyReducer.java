import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<IntWritable, Text, IntWritable, Text> {

	protected void setup(Context context) throws IOException,
			InterruptedException {
		System.out.println("MyReducer.setup(-,-)");
	};

	/*
	 * 980 mahesh,SMCS,Orissa 980 Ratan ,SMCS,Andhra Pradesh 980
	 * [{mahesh,SMCS,Orissa},{Ratan ,SMCS,Andhra Pradesh}]
	 */

	@Override
	public void reduce(IntWritable mark, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		System.out.println("reduce(-,-,-)");// Will be called only once
											// irrespective of the group
		for (Text student : values) {
			context.write(mark, new Text(student));
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException,
			InterruptedException {
		System.out.println("cleanup(-)");

	}

	// Since we are sorting the data in descending order of marks,we will get
	// the highest mark as the first group only
	// We dont need the other group,so just call only 1 group and then break the
	// while loop to stop processing other data.
	//
	// @Override
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		try {
			while (context.nextKey()) {
				reduce(context.getCurrentKey(), context.getValues(), context);
				break; // This is the only line added to break the loop
			}
		} finally {
			cleanup(context);
		}
	}

}