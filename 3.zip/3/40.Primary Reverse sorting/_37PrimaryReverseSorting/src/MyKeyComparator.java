import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class MyKeyComparator  extends WritableComparator{
//Super class doesnot have default constructor
	protected MyKeyComparator() {
		super(Text.class,true);//second parameter will start the buffer,if you dont provide this value,it throws NullPOinterException
		System.out.println("MyKeyComparator()");
		
	}
	@Override
		public int compare(WritableComparable yearOne, WritableComparable yearTwo) {
		System.out.println("MyKeyComparator.compare(-,-)");
		System.out.println(yearOne+"<=>"+yearTwo);
		int year1=Integer.parseInt(((Text)yearOne).toString());
		int year2=Integer.parseInt(((Text)yearTwo).toString());
		
		return -(year1-year2);//1901-1904
		
		//return (year1-year2);//default Implementation
		}
}
	 