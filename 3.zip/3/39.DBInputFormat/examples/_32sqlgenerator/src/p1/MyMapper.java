package p1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

 //Will Process
 //aarti,922,Deendayal Public School,Delhi,aarti@gmail.com
 
public class MyMapper extends Mapper<LongWritable, Text, Text, Text> {
private final String  sql="INSERT INTO STUDENTS VALUES(";
private final Text ONE=new Text("1");
	public void map(LongWritable offset, Text value, Context context)
			throws IOException, InterruptedException {

		String line = value.toString();
		String data[]=line.split(",");
		String sqlQuery=sql+"'"+data[0]+"',"+data[1]+",'"+data[2]+"','"+data[3]+"','"+data[4]+"');\n";
		System.out.println(sqlQuery);
		context.write(ONE,new Text(sqlQuery));
	}
}

//INSERT INTO STUDENTS VALUES('aarti',922,'Deendayal Public School','Delhi','aarti@gmail.com');