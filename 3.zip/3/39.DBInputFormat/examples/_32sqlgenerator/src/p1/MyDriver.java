package p1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.map.TokenCounterMapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
	public static void main(String[] args) throws IOException,
			ClassNotFoundException, InterruptedException {
		Path input_dir = new Path("hdfs://localhost:54310/student_marks");
		Path output_dir = new Path("hdfs://localhost:54310/output_data/");
		// Create a configuration class pointing to default configuration
		Configuration conf = new Configuration();

		// Prepare a Job object
		Job job = new Job(conf, "MyWordCountJob");
		// Link your driver class with the job
		job.setJarByClass(MyDriver.class);

		// Link Mapper with job
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		job.setNumReduceTasks(1);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		
		FileInputFormat.addInputPath(job, input_dir);// Define Input Path
		FileOutputFormat.setOutputPath(job, output_dir);// Add output path to your Job

		output_dir.getFileSystem(conf).delete(output_dir,true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
