package p1;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.lib.db.DBWritable;

public class Student implements Writable,DBWritable {
	//STUDENT_NAME | STUDENT_MARKS | STUDENT_SCHOOL       | STUDENT_STATE  | STUDENT_EMAIL     
	private Text studentName;
	private IntWritable studentMark;
	private Text studentSchool;
	private Text studentState;
	private Text studentEmail;
	
	@Override
	public void write(PreparedStatement pst) throws SQLException {
		pst.setString(0, studentName.toString());
		pst.setInt(1, studentMark.get());
		pst.setString(2, studentSchool.toString());
		pst.setString(3, studentState.toString());
		pst.setString(4, studentEmail.toString());
	}

	@Override
	public void readFields(ResultSet rs) throws SQLException {
		studentName=new Text(rs.getString("STUDENT_NAME"));//can use index 0
		studentMark=new IntWritable(rs.getInt("STUDENT_MARKS"));//index 1
		studentSchool=new Text(rs.getString("STUDENT_SCHOOL"));//can use index 2
		studentState=new Text(rs.getString("STUDENT_STATE"));//can use index 3
		studentEmail=new Text(rs.getString("STUDENT_EMAIL"));//can use index 4
	}

	@Override
	public void write(DataOutput out) throws IOException {
		studentName.write(out);
		studentMark.write(out);
		studentSchool.write(out);
		studentState.write(out);
		studentEmail.write(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		studentName.readFields(in);	
		studentMark.readFields(in);
		studentSchool.readFields(in);
		studentState.readFields(in);
		studentEmail.readFields(in);
	}

	@Override
	public String toString() {
		return studentName+","+studentMark+","+studentSchool+","+studentState+","+ studentEmail;
	}

}
