package p1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.db.DBConfiguration;
import org.apache.hadoop.mapreduce.lib.db.DBInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
	public static void main(String[] args) throws IOException,
			ClassNotFoundException, InterruptedException {
		//Path input_dir = new Path("hdfs://localhost:54310/student_marks");
		Path output_dir = new Path("hdfs://localhost:54310/output_data/");
		// Create a configuration class pointing to default configuration
		Configuration conf = new Configuration();
		//put the jar in /user/hduser/lib hdfs directory
		DistributedCache.addFileToClassPath(new Path("/user/hduser/lib/mysql-connector-java-5.1.34.jar"), conf,output_dir.getFileSystem(conf)); 
		
		DBConfiguration.configureDB(conf, "com.mysql.jdbc.Driver",  
		          "jdbc:mysql://localhost:3306/testdb", "root", "root");  
		
		// Prepare a Job object
		Job job = new Job(conf, "MyWordCountJob");
		// Link your driver class with the job
		job.setJarByClass(MyDriver.class);

		// Link Mapper with job
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		job.setNumReduceTasks(1);
		
		job.setMapOutputKeyClass(LongWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		
		job.setInputFormatClass(DBInputFormat.class);  
		
		      
		     //DBInputFormat.setInput(conf, Student.class, "studentinfo",null, "id", fields);  
		DBInputFormat.setInput(job, Student.class, "SELECT * FROM STUDENTS WHERE STUDENT_MARKS>960", "SELECT COUNT(*) FROM STUDENTS");
		//FileInputFormat.addInputPath(job, input_dir);// Define Input Path
		FileOutputFormat.setOutputPath(job, output_dir);// Add output path to your Job

		output_dir.getFileSystem(conf).delete(output_dir,true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
