package p1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<LongWritable, Text, Text, NullWritable> {
	
	MyReducer(){
		System.out.println("Reducer");
	}
	@Override
	public void reduce(LongWritable word, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		System.out.println("Key="+word);
		for(Text value:values){
			System.out.println(value.toString());
			context.write(value,NullWritable.get());
		}
	}
}