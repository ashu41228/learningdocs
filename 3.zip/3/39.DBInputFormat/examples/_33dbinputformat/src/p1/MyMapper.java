package p1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

 //Will Process
 //aarti,922,Deendayal Public School,Delhi,aarti@gmail.com
 
public class MyMapper extends Mapper<LongWritable, Student, LongWritable, Text> {

	public void map(LongWritable offset, Student student, Context context)
			throws IOException, InterruptedException {

		String line = student.toString();
		
		System.out.println(line);
		context.write(offset,new Text(line));
	}
}